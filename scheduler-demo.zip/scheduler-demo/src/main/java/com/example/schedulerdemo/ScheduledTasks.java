package com.example.schedulerdemo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


@Component
public class ScheduledTasks {

	private static final Logger logger = LoggerFactory.getLogger(ScheduledTasks.class);
    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    
    /**
     * schedule method to be executed in fixed time interval (eg:12 am every day)
     * http://www.quartz-scheduler.org/documentation/quartz-2.x/tutorials/crontrigger.html -->use this to understand cron
     */
    
    @Scheduled(cron = "* * * ? * *")
    public void scheduleTask() {
    
    	final String uri = "https://gturnquist-quoters.cfapps.io/api/random";

        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.getForObject(uri, String.class);

        System.out.println(result);
    	
    	 logger.info("Fixed Rate Task :: Execution Time - {}", dateTimeFormatter.format(LocalDateTime.now()) );
    }
    

}
