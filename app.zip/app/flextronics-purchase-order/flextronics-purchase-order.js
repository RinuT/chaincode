'use strict';

angular.module('myApp.flextronics-purchase-order', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/flextronics-purchase-order', {
    templateUrl: 'flextronics-purchase-order/flextronics-purchase-order.html',
    controller: 'flextronics-purchase-orderCtrl'
  });
}])

.controller('flextronics-purchase-orderCtrl', ['$scope','$http','$timeout',function ($scope,$http,$timeout) {
  $scope.POData=[];
  $scope.poData={}
  $scope.poData.poNumber=""
  $scope.poData.poDate=""
  $scope.poData.poStatus=""
  $scope.search=false
  $scope.BatchId=""
  $scope.PONumber=""
  $scope.LineNo=" "
  $scope.price=" "
  $scope.SEMeterialCode=" "
  $scope.POQty=" "
  $scope.UOP=" "
  $scope.DeliveryDate=" "
 $scope.Currency=" "
 $scope.deliveryNoteNo=" "
 $scope.shippmentDate=" "
 $scope.shippedQty=" "
 $scope.poData.val=" "
 $scope.failuer1=false
 $scope.failuer2=false
  function init(){
  var websocket =new WebSocket("ws://ec2-35-173-231-185.compute-1.amazonaws.com:3000");
  websocket.addEventListener('open',evt =>doSocketOpen(evt));
  websocket.addEventListener('message',evt =>doSocketMessage(evt));
  websocket.addEventListener('close',evt =>doSocketClose(evt));
  }
  function doSocketClose(evt) {
  console.log('Close.');
  }
  function doSocketMessage(evt) {
    let data={}
  data =JSON.parse(evt.data);
  if($scope.search==false){
 
  //for(var i=0;i<data.podata.length;i++){
  $scope.poData.poNumber=data.poNumber
  $scope.poData.poDate=data.purchaseorder.creationDate
  $scope.poData.poStatus=data.purchaseorder.status
  
  if( $scope.poData.poStatus=="Closed"){
    $scope.poData.val=1;
  }
  else
  $scope.poData.val=0;
  $scope.POData.push($scope.poData)
  $scope.POData.length;
  $scope.poData={}
  console.log($scope.POData)
  //}
  }
  else{
 // $scope.batchId=data.purchaseorder.creationDate
 
  $scope.PONumber=data.poNumber
  $scope.LineNo=data.purchaseorder.lineNumber
  $scope.price=data.purchaseorder.price
  $scope.SEMeterialCode=data.purchaseorder.materialCode
  $scope.POQty=data.purchaseorder.quantity
  $scope.UOP=data.purchaseorder.uop
  $scope.POCreationDate=data.purchaseorder.creationDate
  $scope.DeliveryDate=data.purchaseorder.deliveryDate
  $scope.dateC = new Date($scope.POCreationDate); 
  $scope.dateD = new Date($scope.DeliveryDate);
 $scope.Currency=data.purchaseorder.currency
  
  }
  }

  function doSocketOpen(evt) {
  console.log('Open.');
  }
  init()
  var requestInfo = Request();
  var request=
                 {
                  "$class": "com.cts.ipm.p2pNetwork.displayOrders",
                  "supplier":"flextronics"
            }     
  var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/displayOrders',request).then(function successCallback(response){
             $scope.update_response=response;
             $scope.transactionId=$scope.update_response.data.transactionId
            
             
         }, function errorCallback(response){
             $scope.failuer1=true
         });

   
   function Request() {
   
     return {
       "Request" : {
        "$class": "com.cts.ipm.p2pNetwork.displayOrders",
        "supplier": "flextronics"
        
        }
       }
     };
  $scope.submit=function(id){
      $scope.id=id
      $scope.search=true
      console.log(id)
      $scope.setSearchValue()

  }
  $scope.setSearchValue=function() {
     var request=
                 {
                  "$class": "com.cts.ipm.p2pNetwork.searchOrder",
                  "poNumber": $scope.id
            }
            
       var requestInfo = RequestSearch();
     
       data : requestInfo
   
     var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/searchOrder',request).then(function successCallback(response){
             //$scope.update_response=response;
             
            
            // $scope.transactionId=$scope.update_response.data.transactionId
             
         }, function errorCallback(response){

         });
   }
   

function RequestSearch() {
   
   return {
        
    "Request" : {
        "$class": "com.cts.ipm.p2pNetwork.searchOrder",
        "poNumber": ""
      }
     }
   };
   $scope.proceed=function(){
      $scope.search=true
      $scope.setProceed()

  }
  $scope.setProceed=function() {
    var shipmentDate = new Date();
    shipmentDate=$scope.ShipmentDate
     var request=
                 {
                  "$class": "com.cts.ipm.p2pNetwork.ShipmentNotification",
                "batchId": $scope.BatchId,
                "deliverynote": {
                "$class": "com.cts.ipm.p2pNetwork.delNote",
                "poNumber": $scope.PONumber,
                "lineNumber":  $scope.LineNo,
                "deliveryNoteNumber": $scope.deliveryNoteNumber,
                "materialCode": $scope.SEMeterialCode,
                "quantity": $scope.POQty,
                "UOP": $scope.UOP,
                "shipmentDate": shipmentDate.toString(),
                "shipmentQuantity": $scope.shipmentQuantity,
                "supplierId": "flextronics"
            }
                 }
            
       var requestInfo = RequestProceed();
     
       data : requestInfo
   
     var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/ShipmentNotification',request).then(function successCallback(response){
             $scope.update_response=response;
             $scope.transactionId=$scope.update_response.data.transactionId
             $scope.sucess=true
             
         }, function errorCallback(response){
          $scope.failuer2=true
         });
   }
   

function RequestProceed() {
   
   return {
        
    "Request" : {
        "$class": "com.cts.ipm.p2pNetwork.ShipmentNotification",
        "batchId": " ",
        "deliverynote": {
          "$class": "com.cts.ipm.p2pNetwork.delNote",
          "poNumber": " ",
          "lineNumber": " ",
          "deliveryNoteNumber": " ",
          "materialCode": " ",
          "quantity": " ",
          "UOP": " ",
          "shipmentDate": " ",
          "shipmentQuantity": " ",
          "supplierId": " ",
         
      }
      }
     }

   };
}]);