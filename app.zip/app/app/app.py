import urllib
import urllib2
import json
from flask import Flask,jsonify,render_template,make_response,request
app = Flask(__name__)

@app.route('/dashboard')
def dashboard():
    return make_response(render_template('dashboard2.html'),200)

@app.route('/vendor')
def vendor():
    return make_response(render_template('vendor.html'),200)

@app.route('/select')
def select():
    return make_response(render_template('select.html'),200)
	

@app.route('/procurement_quotes')
def procurement_quotes():
    return make_response(render_template('procurement_quotes.html'),200)
	
@app.route('/procurement_requests')
def procurement_requests():
    return make_response(render_template('procurement_requests.html'),200)
	
@app.route('/finalized_quotes')
def finalized_quotes():
    return make_response(render_template('finalized_quotes.html'),200)

	
@app.route('/vendor_list')
def vendor_list():
    return make_response(render_template('vendor_list.html'),200)
	
@app.route('/')
def index():
    return make_response(render_template('procurement_quotes.html'),200)

@app.route('/setValue',methods=['POST'])
def setValue():
    transxId=""
    #try:
    uuid = request.form['uuid']
    factory = request.form['factory']
    make = request.form["make"]
    batch = request.form["batch"]
    rawMat = request.form["rawma"]
    material = request.form["material"]
    print('Setting the values to ',uuid,factory,make,batch,rawMat,material)
    data='''{
  "$class": "com.cts.ipm.track.CreateProduct",
  "uuid": "xxxuuidxxx",
  "product": {
    "$class": "com.cts.ipm.track.Product",
    "material": "xxxmaterialxxx",
    "make": "xxxmakexxx",
    "rawMaterialLocation": "xxxrawmatxxx",
    "productStatus": "IN_GOOD_CONDITION",
    "shipmentStatus": "IN_PRODUCTION",
    "batchCode": "xxxbatchxxx"
  }
}'''
    data=data.replace("xxxmaterialxxx",material)
    data=data.replace("xxxuuidxxx",uuid)
    data=data.replace("xxxmakexxx",make)
    data=data.replace("xxxrawmatxxx",rawMat)
    data=data.replace("xxxbatchxxx",batch)

    req = urllib2.Request("https://track-and-trace-network.mybluemix.net/api/CreateProduct",data)
    req.add_header("Content-Type","application/json")
    result = urllib2.urlopen(req)
    ans=result.read()
    ans=json.loads(ans)
    transxId=ans['transactionId']
    #updating latest uuid in aws
    urllib2.urlopen("http://52.23.188.216:7500/updateUuid?value="+str(uuid))
    #except Exception as e:
    #    print(e)
    return jsonify(transxId)


if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True,port=9001,threaded=True)
