'use strict';

angular.module('myApp.invoice', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/invoice', {
    templateUrl: 'invoice/invoice.html',
    controller: 'invoiceCtrl'
  });
}])

.controller('invoiceCtrl', ['$scope','$http','$timeout',function ($scope,$http,$timeout) {
  $scope.PODataUnpaid=[];
  $scope.notGenerated=[];
  $scope.PODataPaid=[];
  $scope.poData={}
  $scope.poData.invoiceNo=""
  $scope.poData.invoiceStatus=""
  $scope.poData.consumptionQuantity=""
  $scope.poData.diffDays=""
  $scope.poData.materialCode=""
  $scope.val="1"
  $scope.Search=false
  $scope.Search1=false
  $scope.fialuier2=false
  $scope.fialuier=false
  $scope.fialuier1=false
  $scope.BatchId=""
  $scope.PONumber=""
  $scope.LineNo=" "
  $scope.price=" "
  $scope.SEmaterialCode=" "
  $scope.POQty=" "
  $scope.UOP=" "
  $scope.DeliveryDate=" "
 $scope.Currency=" "
 $scope.deliveryNoteNo=" "
 $scope.shippmentDate=" "
 $scope.shippedQty=" "
 $scope.Unpaid=false
 $scope.notGen=false
 $scope.paid=false
 $scope.display=true
 $scope.Pending=false
  $scope.PODataPending=[]
  function init(){
  var websocket =new WebSocket("ws://ec2-35-173-231-185.compute-1.amazonaws.com:3000");
  websocket.addEventListener('open',evt =>doSocketOpen(evt));
  websocket.addEventListener('message',evt =>doSocketMessage(evt));
  websocket.addEventListener('close',evt =>doSocketClose(evt));
  }
  function doSocketClose(evt) {
  console.log('Close.');
  }
  function doSocketMessage(evt) {
    let data={}
    $scope.poData={}
  data =JSON.parse(evt.data);
  var datetime = new Date();
  console.log(datetime);
  if($scope.display==true){
  var date1 = new Date(datetime);

    $scope.poData.invoiceNo=data.invDocNum
    $scope.poData.materialCode=data.selfinvoice.materialCode
  $scope.poData.invoiceStatus=data.invoiceStatus
  if(data.selfinvoice.consumptionQuantity!=undefined)
  $scope.poData.consumptionQuantity=data.selfinvoice.consumptionQuantity
  else
  $scope.poData.consumptionQuantity=data.selfinvoice.quantity
  if(data.selfinvoice.receiptDate!=undefined)
  var date2 = new Date( data.selfinvoice.receiptDate);
  else
  var date2 = new Date( data.selfinvoice.materialDoceDate);
  var timeDiff = Math.abs(date2.getTime() - date1.getTime());
  $scope.poData.diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    if( $scope.poData.invoiceStatus=="Not Genetrated"){
      $scope.notGen=true
  $scope.notGenerated.push($scope.poData)
 
  } else if( $scope.poData.invoiceStatus=="Invoice Generated"){
  $scope.Unpaid=true
  $scope.PODataUnpaid.push($scope.poData)
 
  }
  else if( $scope.poData.invoiceStatus=="Pending"){
  $scope.Pending=true
  $scope.PODataPending.push($scope.poData)
 
  } else{
 $scope.paid=true
    $scope.PODataPaid.push($scope.poData)
  }
  }
  else{
    $scope.invoiceId=data.invDocNum
    $scope.perUnitPrice=data.amount
    $scope.poNumber=data.selfinvoice.poNumber
    $scope.materialCode=data.selfinvoice.materialCode 
    if(data.selfinvoice.consumptionQuantity!=undefined)
  $scope.quantity=data.selfinvoice.consumptionQuantity
  else
  $scope.quantity=data.selfinvoice.quantity
  $scope.totalPrice=$scope.quantity*data.amount 

  }
  
  evt.data=""
  data =JSON.parse(evt.data);
  console.log(data)
  //window.location.reload();
  }

  function doSocketOpen(evt) {
  console.log('Open.');
  }
  init()
  var requestInfo = Request();
  var request=
                 {
                  "$class": "com.cts.ipm.p2pNetwork.displayInvoice"
            }     
  var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/displayInvoice',request).then(function successCallback(response){
             $scope.update_response=response;
             $scope.transactionId=$scope.update_response.data.transactionId
            
             
         }, function errorCallback(response){
             console.log("POST-ing of data failed");
         });

   
   function Request() {
   
     return {
       "Request" : {
        "$class": "com.cts.ipm.p2pNetwork.displayInvoice"
        
       }
       }
     };     
     
     $scope.submit = function(id){
       $scope.ID=id
 $scope.setValue();
 }
 $scope.setValue=function() {
           $scope.display=false
   var request=
               {
                 "$class": "com.cts.ipm.p2pNetwork.searchInvoice",
                 "invDocNum":  $scope.ID
                 
               }
     var requestInfo = Request();
   
     data : requestInfo
 
   var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/searchInvoice',request).then(function successCallback(response){
           //alert("Successfully placed order");
           $scope.update_response=response;
           $scope.Search=true
           $scope.transactionId=$scope.update_response.data.transactionId
           
       }, function errorCallback(response){
         $scope.fialuier1=true
       });
 }

 function Request() {
 
   return {
     "Request" :   {
       "$class": "com.cts.ipm.p2pNetwork.searchInvoice",
    "invDocNum":" "
     }
   }
   };
$scope.pay = function(){
 $scope.setValuePay();
 }
 $scope.setValuePay=function() {
   var requestPay=
               {
                
                "$class": "com.cts.ipm.p2pNetwork.Payment",
                "invDocNum":  $scope.ID
              
               }
     var requestInfo = RequestPay();
   
     data : requestInfo
 
   var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/Payment',requestPay).then(function successCallback(response){
        //   alert("Successfully placed order");
           $scope.update_response=response;
          
           $scope.sucess1=true
           $scope.transactionId=$scope.update_response.data.transactionId
           
       }, function errorCallback(response){
         $scope.fialuier=true
       });
 }
 $scope.navigate=function(url){
  window.location = url;

}
 function RequestPay() {
 
   return {
     "Request" : {
      "$class": "com.cts.ipm.p2pNetwork.Payment",
    "invDocNum": " " 
      }
     }
   };
  
$scope.generate = function(id){
  $scope.invoice=id
 $scope.setValueInvoice();
 }
 $scope.setValueInvoice=function() {
   var requestInvoice=
   {
      "$class": "com.cts.ipm.p2pNetwork.generateInvoice",
      "invDocNum":    $scope.invoice,
      "selfinvoice": {
        "$class": "com.cts.ipm.p2pNetwork.SelfInvoice",
        "selfinvoice": {
          "$class": "com.cts.ipm.p2pNetwork.newSelfInvoice",
          "poNumber": "",
          "lineNum": "",
          "materialCode": "",
          "quantity": "",
          "UOP": "",
          "materialDoceDate": "",
          "consumptionQuantity": ""
        },
        "invoiceStatus": "Pending",
        "amount": "",
        "invDocNum": " "
      }
    }

     var requestInfo = RequestInvoice();
   
     data : requestInfo
 
   var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/generateInvoice',requestInvoice).then(function successCallback(response){
        //   alert("Successfully placed order");
           $scope.update_response=response;
          
           $scope.Search1=true
           $scope.sucess2=true
           $scope.transactionId=$scope.update_response.data.transactionId
           
       }, function errorCallback(response){
         $scope.fialuier3=true
       });
 }
 $scope.navigate=function(url){
  window.location = url;

}
 function RequestInvoice() {
 
   return {
     "Request" : {
        "$class": "com.cts.ipm.p2pNetwork.generateInvoice",
        "invDocNum": "",
        "selfinvoice": {
          "$class": "com.cts.ipm.p2pNetwork.SelfInvoice",
          "selfinvoice": {
            "$class": "com.cts.ipm.p2pNetwork.newSelfInvoice",
            "poNumber": "",
            "lineNum": "",
            "materialCode": "",
            "quantity": "",
            "UOP": "",
            "materialDoceDate": "",
            "consumptionQuantity": ""
          },
          "invoiceStatus": "",
          "amount": "",
          "invDocNum": " "
        }
      }

     }
   };
   }]);