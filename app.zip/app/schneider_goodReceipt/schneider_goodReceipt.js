'use strict';

angular.module('myApp.schneider_goodReceipt', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/schneider_goodReceipt', {
    templateUrl: 'schneider_goodReceipt/schneider_goodReceipt.html',
    controller:'schneider_goodReceiptCtrl'
  });
}])

.controller('schneider_goodReceiptCtrl', ['$scope','$http','$timeout',function ($scope,$http,$timeout) {
    $scope.fialuier=false
    $scope.sucess=false
    var acc = document.getElementsByClassName("accordion");
    var i;
    $scope.CreationDate = new Date();
    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.maxHeight){
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + "px";
        } 
      });
    }
    $scope.navigate=function(url){
      window.location = url;

    }
    $scope.POData=[];
    $scope.poData={}
    $scope.poData.poNumber=""
    $scope.poData.poDate=""
    $scope.poData.poStatus=""
    $scope.search=false
    $scope.BatchId=""
    $scope.PONumber=""
    $scope.LineNo=" "
    $scope.price=" "
    $scope.SEmaterialCode=" "
    $scope.POQty=" "
    $scope.UOP=" "
    $scope.DeliveryDate=" "
   $scope.Currency=" "
   $scope.deliveryNoteNo=" "
   $scope.shippmentDate=" "
   $scope.shippedQty=" "
   $scope.poData.val=" "
   $scope.failuer1=false
   $scope.failuer2=false
   $scope.Batch={}
   $scope.data=""
   $scope.Batch.shippedQuantity=" "
   $scope.Batch.batchCode=" "
      $scope.Batch.batchStatus=" "
       $scope.batch=[]
    function init(){
    var websocket =new WebSocket("ws://ec2-35-173-231-185.compute-1.amazonaws.com:3000");
    websocket.addEventListener('open',evt =>doSocketOpen(evt));
    websocket.addEventListener('message',evt =>doSocketMessage(evt));
    websocket.addEventListener('close',evt =>doSocketClose(evt));
    }
    function doSocketClose(evt) {
    console.log('Close.');
    }
    function doSocketMessage(evt) {
      let data={}
    data =JSON.parse(evt.data);
    if($scope.search==false){
   
    //for(var i=0;i<data.podata.length;i++){
    $scope.poData.poNumber=data.poNumber
    $scope.poData.poDate=data.purchaseorder.creationDate
    $scope.poData.poStatus=data.purchaseorder.status
    
    if( $scope.poData.poStatus=="Closed"){
      $scope.poData.val=1;
    }
    else
    $scope.poData.val=0;
    $scope.POData.push($scope.poData)
    $scope.POData.length;
    $scope.poData={}
    //}
    }
    else{
  
    $scope.PONumber=data.poNumber
    $scope.LineNo=data.purchaseorder.lineNumber
    $scope.price=data.purchaseorder.price
    $scope.SEmaterialCode=data.purchaseorder.materialCode
    $scope.POQty=data.purchaseorder.orderQuantity
    $scope.totalRecieved=data.purchaseorder.receivedQuantity
    $scope.requirment=data.purchaseorder.requiredQuantity
    $scope.UOP=data.purchaseorder.uop
    $scope.POCreationDate=data.purchaseorder.creationDate
    $scope.DeliveryDate=data.purchaseorder.deliveryDate
    $scope.dateC = new Date($scope.POCreationDate); 
    $scope.dateD = new Date($scope.DeliveryDate);
   $scope.Currency=data.purchaseorder.currency
   for(var i=0;i<data.purchaseorder.batch.length;i++){
      $scope.Batch.batchCode=data.purchaseorder.batch[i].batchCode
      $scope.Batch.shippedQuantity=data.purchaseorder.batch[i].batch.shippedQuantity
      $scope.Batch.batchStatus=data.purchaseorder.batch[i].batch.batchStatus
       $scope.batch.push($scope.Batch)
   }
    
    }
    evt.data=""
    data =JSON.parse(evt.data);
    console.log(data)
    }

    function doSocketOpen(evt) {
    console.log('Open.');
    }
    init()

    $scope.submit=function(id){
        $scope.id=id
        $scope.search=true
        console.log(id)
        $scope.setSearchValue()

    }
    $scope.setSearchValue=function() {
       var request=
                   {
                    "$class": "com.cts.ipm.p2pNetwork.searchOrder",
                    "poNumber": $scope.id
              }
              
         var requestInfo = RequestSearch();
       
         data : requestInfo
     
       var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/searchOrder',request).then(function successCallback(response){

           }, function errorCallback(response){

           });
     }
     

  function RequestSearch() {
     
     return {
          
      "Request" : {
          "$class": "com.cts.ipm.p2pNetwork.searchOrder",
          "poNumber": ""
        }
       }
     };
     $scope.proceed=function(data){
        $scope.search=true
        $scope.data=data
        if($scope.requiredQuantity<$scope.shipmentQuantity){
          alert("shipped Quantity more tyhan required quantity")
        }
        else
        $scope.setProceed()

    }
    $scope.setProceed=function() {
      var shipmentDate = new Date();
      shipmentDate=$scope.ShipmentDate
     var CreationDate = new Date();
     CreationDate=$scope.dateC
     if(CreationDate <shipmentDate){
      var request=
                
                   {
              "$class": "com.cts.ipm.p2pNetwork.GoodsReceipt",
              "receiptId": $scope.data,
              "goodreceipt": {
                  "$class": "com.cts.ipm.p2pNetwork.receipt",
                  "poNumber": $scope.PONumber,
                  "lineNumber": "",
                  "materialCode": $scope.SEmaterialCode,
                  "quantity": "",
                  "UOP": "",
                  "receiptDate": shipmentDate.toString(),
                  "receivedQuantity":  $scope.shipmentQuantity,
                  "batchId": $scope.data,
                  "invoiceStatus": ""
              }
              }
              
         var requestInfo = RequestProceed();
       
         data : requestInfo
     
       var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/GoodsReceipt',request).then(function successCallback(response){
               $scope.update_response=response;
               $scope.transactionId=$scope.update_response.data.transactionId
               $scope.sucess=true
               
           }, function errorCallback(response){
            $scope.failuer2=true
           });
     }
     else
     {
       alert("Shipment Date should be less than creation date")
     }
      
     }
     

  function RequestProceed() {
     
     return {
          
      "Request" :{
              "$class": "com.cts.ipm.p2pNetwork.GoodsReceipt",
              "receiptId": "",
              "goodreceipt": {
                  "$class": "com.cts.ipm.p2pNetwork.receipt",
                  "poNumber": "",
                  "lineNumber": "",
                  "materialCode": "",
                  "quantity": "",
                  "UOP": "",
                  "receiptDate": "",
                  "receivedQuantity": "",
                  "batchId": "",
                  "invoiceStatus": ""
              }
              }
       }

     };
     }]);