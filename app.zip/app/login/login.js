'use strict';

angular.module('myApp.flextronics-purchase-order', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/flextronics-purchase-order', {
    templateUrl: 'flextronics-purchase-order/flextronics-purchase-order.html',
    controller: 'flextronics-purchase-orderCtrl'
  });
}])

.controller('flextronics-purchase-orderCtrl', ['$scope','$http','$timeout',function ($scope,$http,$timeout) {

   
}]);