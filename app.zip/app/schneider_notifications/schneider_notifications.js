'use strict';

angular.module('myApp.schneider_notifications', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/schneider_notifications', {
    templateUrl: 'schneider_notifications/schneider_notifications.html',
    controller:'schneider_notificationsCtrl'
  });
}])

.controller('schneider_notificationsCtrl', ['$scope','$http','$timeout',function ($scope,$http,$timeout) {
  $scope.PODataUnpaid=[];
  $scope.poData={}
  $scope.poData.poNumber=""
  $scope.poData.diffDays=""
  $scope.poData.poStatus=""
  $scope.poData.batchId=""
  $scope.poData.materialCode=""
  $scope.val="1"
  $scope.search=false
  $scope.BatchId=""
  $scope.PONumber=""
  $scope.LineNo=" "
  $scope.price=" "
  $scope.SEmaterialCode=" "
  $scope.POQty=" "
  $scope.UOP=" "
  $scope.DeliveryDate=" "
 $scope.Currency=" "
 $scope.deliveryNoteNo=" "
 $scope.shippmentDate=" "
 $scope.shippedQty=" "
 $scope.invoiceId=""
 $scope.search=false
$scope.Pending=false
 var acc = document.getElementsByClassName("accordion");
var i;
$scope.CreationDate = new Date();
for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}
  function init(){
  var websocket =new WebSocket("ws://ec2-35-173-231-185.compute-1.amazonaws.com:3000");
  websocket.addEventListener('open',evt =>doSocketOpen(evt));
  websocket.addEventListener('message',evt =>doSocketMessage(evt));
  websocket.addEventListener('close',evt =>doSocketClose(evt));
  }
  function doSocketClose(evt) {
  console.log('Close.');
  }
  function doSocketMessage(evt) {
    let data={}
  data =JSON.parse(evt.data);

  for(var i=0;i<data.batch.length;i++){
    if(data.batch[i].quantity>0 & data.batch[i].invoiceStatus=="Not Generated"){
    $scope.poData.batch=data.batch[i].batchId
    $scope.poData.poNumber=data.batch[i].poNumber
    $scope.poData.materialCode=data.batch[i].materialCode
    $scope.poData.quantity=data.batch[i].quantity
    $scope.PODataUnpaid.push($scope.poData)
    $scope.poData={}
    $scope.Pending=true
  } 

  }
  evt.data=""
  data =JSON.parse(evt.data);
  console.log(data)
  if($scope.PODataUnpaid.length==0){
$scope.fall=true
}
  }

  function doSocketOpen(evt) {
  console.log('Open.');
  }
  init()
  var requestInfo = Request();
  var request=
                 {
                  "$class": "com.cts.ipm.p2pNetwork.display"
            }     
  var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/display',request).then(function successCallback(response){
             $scope.update_response=response;
             $scope.sucess=true
             $scope.transactionId=$scope.update_response.data.transactionId
            
             
         }, function errorCallback(response){
             console.log("POST-ing of data failed");
         });

   
   function Request() {
   
     return {
       "Request" : {
        "$class":  "com.cts.ipm.p2pNetwork.display"
        
       }
       }
     };
     $scope.generate= function(){
 $scope.setValueInvoice();
 }
 $scope.generateInvoice = function(){
  $scope.search=true
 }
 $scope.setValueInvoice=function() {
  $scope.CreationDate = new Date();
   var requestInvoice=
   {
      "$class": "com.cts.ipm.p2pNetwork.generateInvoice",
      "invDocNum":    $scope.invoiceId,
      "selfinvoice": {
        "$class": "com.cts.ipm.p2pNetwork.SelfInvoice",
        "selfinvoice": {
          "$class": "com.cts.ipm.p2pNetwork.newSelfInvoice",
          "poNumber": "",
          "lineNum": "",
          "materialCode": "",
          "quantity": "",
          "UOP": "",
          "materialDoceDate":   $scope.CreationDate.toString(),
          "consumptionQuantity": "0"
        },
        "invoiceStatus": "",
        "amount": "",
        "invDocNum": $scope.invoiceId
      }
    }

     var requestInfo = RequestInvoice();
   
     data : requestInfo
 
   var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/generateInvoice',requestInvoice).then(function successCallback(response){
        //   alert("Successfully placed order");
           $scope.update_response=response;
          
           $scope.Search1=true
           $scope.sucess2=true
           $scope.transactionId=$scope.update_response.data.transactionId
           
       }, function errorCallback(response){
         $scope.fialuier3=true
       });
 }
 $scope.navigate=function(url){
  window.location = url;

}
 function RequestInvoice() {
 
   return {
     "Request" : {
        "$class": "com.cts.ipm.p2pNetwork.generateInvoice",
        "invDocNum": "",
        "selfinvoice": {
          "$class": "com.cts.ipm.p2pNetwork.SelfInvoice",
          "selfinvoice": {
            "$class": "com.cts.ipm.p2pNetwork.newSelfInvoice",
            "poNumber": "",
            "lineNum": "",
            "materialCode": "",
            "quantity": "",
            "UOP": "",
            "materialDoceDate": "",
            "consumptionQuantity": ""
          },
          "invoiceStatus": "",
          "amount": "",
          "invDocNum": " "
        }
      }

     }
   };
 }]);
