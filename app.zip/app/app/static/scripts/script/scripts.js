
function store_procu_data() {
    var procurement_id = $('#textarea2').val();
    var vendor_name = $('#textarea1').val();
    var item = $('#textarea4').val();
    var quantity = $('#textarea5').val();
    var price = $('#textarea6').val();
    var email_id = $('#textarea3').val();
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://52.90.176.69:8050/addquote",
        "method": "POST",
        "headers": {
          "content-type": "application/json",
          "cache-control": "no-cache"
        },
        "processData": false,
        "data": "{\n\t\"procurement_id\" : \""+procurement_id+"\",\n\t\"vendor_name\" : \""+vendor_name+"\",\n\t\"item\":\""+item+"\",\n\t\"quantity\" :\""+quantity+"\",\n\t\"price\" : \""+price+"\",\n\t\"email_id\" : \""+email_id+"\"\n}"
    }


      $.ajax(settings).done(function (response) {
          M.toast({html: 'Quote Succesfully Sent. We will reach you shortly.'})
          $("#textarea1").val("");
          $("#textarea2").val("");
          $("#textarea3").val("");
          $("#textarea4").val("");
          $("#textarea5").val("");
          $("#textarea6").val("");
      });
  }
