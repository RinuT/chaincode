'use strict';

angular.module('myApp.schneider_payment', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/schneider_payment', {
    templateUrl: 'schneider_payment/schneider_payment.html',
    controller:'schneider_paymentCtrl'
  });
}])

.controller('schneider_paymentCtrl', ['$scope','$http','$timeout',function ($scope,$http,$timeout) {
  var acc = document.getElementsByClassName("accordion");
  var i;
  $scope.fialuier1=false
  $scope.Search=false
  $scope.fialuier=false
  for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var panel = this.nextElementSibling;
      if (panel.style.maxHeight){
        panel.style.maxHeight = null;
      } else {
        panel.style.maxHeight = panel.scrollHeight + "px";
      } 
    });
  }
  function init(){
    var websocket =new WebSocket("ws://ec2-35-173-231-185.compute-1.amazonaws.com:3000");
    websocket.addEventListener('open',evt =>doSocketOpen(evt));
    websocket.addEventListener('message',evt =>doSocketMessage(evt));
    websocket.addEventListener('close',evt =>doSocketClose(evt));
    }
    function doSocketClose(evt) {
    console.log('Close.');
    }
    function doSocketMessage(evt) {
    data =JSON.parse(evt.data);
    if(data.selfinvoice.consumptionQuantity!=undefined)
    $scope.quantity=data.selfinvoice.consumptionQuantity
    else
    $scope.quantity=data.selfinvoice.quantity
    $scope.perUnitPrice=data.amount 
    $scope.totalPrice=$scope.quantity*data.amount 
    $scope.Search=true
   // $scope.status=data.invoiceStatus
    }

    function doSocketOpen(evt) {
    console.log('Open.');
    }
    init();
   $scope.submit = function(){
   $scope.setValue();
   }
   $scope.setValue=function() {
     var request=
                 {
                   "$class": "com.cts.ipm.p2pNetwork.searchInvoice",
                   "invDocNum": $scope.invoiceId
                   
                 }
       var requestInfo = Request();
     
       data : requestInfo
   
     var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/searchInvoice',request).then(function successCallback(response){
             //alert("Successfully placed order");
             $scope.update_response=response;
             $scope.sucess=true
             $scope.Search=true
             $scope.transactionId=$scope.update_response.data.transactionId
             
         }, function errorCallback(response){
           $scope.fialuier1=true
         });
   }

   function Request() {
   
     return {
       "Request" :   {
         "$class": "com.cts.ipm.p2pNetwork.searchInvoice",
      "invDocNum":" "
       }
     }
     };
  $scope.pay = function(){
   $scope.setValuePay();
   }
   $scope.setValuePay=function() {
     var requestPay=
                 {
                  
                  "$class": "com.cts.ipm.p2pNetwork.Payment",
                  "invDocNum":  $scope.invoiceId
                
                 }
       var requestInfo = RequestPay();
     
       data : requestInfo
   
     var res = $http.post('http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/Payment',requestPay).then(function successCallback(response){
          //   alert("Successfully placed order");
             $scope.update_response=response;
            
             $scope.sucess1=true
             $scope.transactionId=$scope.update_response.data.transactionId
             
         }, function errorCallback(response){
           $scope.fialuier=true
         });
   }
   $scope.navigate=function(url){
    window.location = url;

  }
   function RequestPay() {
   
     return {
       "Request" : {
        "$class": "com.cts.ipm.p2pNetwork.Payment",
      "invDocNum": " " 
        }
       }
     };
   }]);