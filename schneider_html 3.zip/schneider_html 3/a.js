/**
   * Place an order for the material
   * @param {com.cts.ipm.p2pNetwork.displayOrders} displayorder - the PlaceOrder transaction
   * @transaction
   */
async function displayOrders(search) {
  const results = await query('selectProductBysupplier', {supplier : search.supplier});
  const factory = getFactory();
  if(results.length>0) {
    for(let i=0;i<results.length;i++){
    const productRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.PurchaseOrder');
    const SearchOrderEvent = factory.newEvent('com.cts.ipm.p2pNetwork', 'SearchOrderEvent');
    SearchOrderEvent.poNumber = results[i].poNumber;
    SearchOrderEvent.purchaseorder = results[i].purchaseorder;
    emit(SearchOrderEvent);
  }
  }
  else
    throw new Error('Supplier not available for given id');   
  }
/**new_material
 * Search the order by poNumber
 * @param {com.cts.ipm.p2pNetwork.RecordConsumption} record - 
 * @transaction
 */
async function RecordConsumption(record) {  // eslint-disable-line no-unused-vars
    const namespace = "com.cts.ipm.p2pNetwork";
      const factory = getFactory();
      const materialRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.Material');
      const new_material = await materialRegistry.get(record.consumptionrecord.materialCode);
      const invoiceRegisry = await getAssetRegistry('com.cts.ipm.p2pNetwork.SelfInvoice');  

        let sup = record.consumptionrecord.consumptionQuantity
        let sum = 0;
        let need = 0
             for(let i=0;i<new_material.purchaseOrder.length;i++){
                   console.log("1")
             if(new_material.purchaseOrder[i].purchaseorder.availableQuantity>0){
                   console.log("2")
                 for(let j=0;j<new_material.purchaseOrder[i].purchaseorder.batch.length;j++){
               need=sup-sum
               if(sum<sup){
                 if(new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity!=0){
                    if(need==new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity||
                       need>new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity){
          let temp=new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity
          sum+=parseInt(new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity)
          new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity="0"
                      new_material.purchaseOrder[i].purchaseorder.availableQuantity=
            (new_material.purchaseOrder[i].purchaseorder.availableQuantity-need).toString();
          
                    }
          else{
            sum+=need
            
                      console.log("new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity")
                      console.log(new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity)
            new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity=(parseInt(new_material.purchaseOrder[i].purchaseorder.batch[j].batch.availableQuantity)-need).toString(); 
            new_material.purchaseOrder[i].purchaseorder.availableQuantity=
            (new_material.purchaseOrder[i].purchaseorder.availableQuantity-need).toString();
          console.log(new_material)
          }
                       console.log("out")
          const invoice = factory.newResource('com.cts.ipm.p2pNetwork', 'SelfInvoice',record.consumptionrecord.invDocNum+new_material.purchaseOrder[i].purchaseorder.batch[j].batchCode);
          invoice.selfinvoice = record.consumptionrecord;
          invoice.amount = new_material.purchaseOrder[i].purchaseorder.price;
          invoice.invoiceStatus = "Invoice Generated"
                   console.log(invoice)
          await invoiceRegisry.add(invoice)
      
          if(new_material.purchaseOrder[i].purchaseorder.batch[j].batch.invoice.length==0){
            new_material.purchaseOrder[i].purchaseorder.batch[j].batch.invoice=[invoice] 
          }else{
            new_material.purchaseOrder[i].purchaseorder.batch[j].batch.invoice.push(invoice)
          }
          
        }
        }else if(sum==sup){
          break;
                }
               }
            }
             
            }
      
   new_material.availableQuantity = (new_material.availableQuantity-record.consumptionrecord.consumptionQuantity).toString();
   console.log(new_material)
        await materialRegistry.update(new_material);  
              console.log(new_material)
             
            
           // const orderRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.PurchaseOrder');
           // const order = await orderRegistry.get(record.consumptionrecord.poNumber)
            //  const order = await query('selectProductBypoNumber', {poNumber : record.consumptionrecord.poNumber});
          //  console.log(order)
            // 
         
  

    }
  
/**
 * Search the order by poNumber
 * @param {com.cts.ipm.p2pNetwork.GoodsReceipt} receipt - 
 * @transaction
 */
async function GoodsReceipt(receipt) { 
    const registry = await getAssetRegistry('com.cts.ipm.p2pNetwork.GoodReceipt');
    const materialRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.Material');
    const productRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.PurchaseOrder');
    const batchRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.newBatch');
    const factory = getFactory(); 
    const results = await query('selectProductBypoNumber', {poNumber : receipt.goodreceipt.poNumber});
    if(results.length>0) {
    
    const update_po = await productRegistry.get(receipt.goodreceipt.poNumber);
    const batch = await query('selectProductByBatch', {batchCode : receipt.goodreceipt.batchId});
    if(batch.length>0  ){
      console.log(batch[0])
        if(batch[0].batch.batchStatus=="Shipped"){
      const update_batch = await batchRegistry.get(receipt.goodreceipt.batchId);
      
      if(update_batch.batch.shippedQuantity<receipt.goodreceipt.recievedQuantity)
      {
          throw console.error("Recived quantity greater than shipped quantity");
      }
      else{
      console.log(update_batch)
          update_batch.batch.availableQuantity=receipt.goodreceipt.receivedQuantity
          update_batch.batch.recievedQuantity=receipt.goodreceipt.receivedQuantity
          update_batch.batch.batchStatus="recieved"
        console.log(update_po.purchaseorder.receivedQuantity+" . "+receipt.goodreceipt.receivedQuantity)
          update_po.purchaseorder.receivedQuantity= (parseInt(update_po.purchaseorder.receivedQuantity)+parseInt(receipt.goodreceipt.receivedQuantity)).toString();
          update_po.purchaseorder.availableQuantity= (parseInt(update_po.purchaseorder.availableQuantity)+parseInt(receipt.goodreceipt.receivedQuantity)).toString();
          if(update_batch.batch.shippedQuantity>receipt.goodreceipt.receivedQuantity){
            console.log("inside")
              update_po.purchaseorder.requiredQuantity=(parseInt(update_po.purchaseorder.requiredQuantity)+(parseInt(update_batch.batch.shippedQuantity)-parseInt(receipt.goodreceipt.receivedQuantity))).toString()
            console.log(update_po)
             
          }
         for(var i=0;i<update_po.purchaseorder.batch.length;i++){
                  if(update_po.purchaseorder.batch[i].batchCode==update_batch.batchCode){
                      update_po.purchaseorder.batch[i].batch=update_batch.batch
                    console.log(update_po)
                  }
              }
      }
     await batchRegistry.update(update_batch)
     await productRegistry.update(update_po)
  
  const material = await query('selectProductBymaterialCode', {materialCode : receipt.goodreceipt.materialCode});
    if(material.length>0){
      const update_material = await materialRegistry.get(receipt.goodreceipt.materialCode);
      update_material.receivedQuantity=(parseInt(update_material.receivedQuantity)+parseInt(receipt.goodreceipt.receivedQuantity)).toString();
      update_material.availableQuantity= (parseInt(update_material.availableQuantity)+parseInt(receipt.goodreceipt.receivedQuantity)).toString();
      
      for(var j=0;j<update_material.purchaseOrder.length;j++){
      if(update_material.purchaseOrder[j].poNumber==update_po.poNumber){
        update_material.purchaseOrder[j]=update_po
      }
      }
     await materialRegistry.update(update_material)

    }
  
      else{
          const new_material = factory.newResource('com.cts.ipm.p2pNetwork', 'Material', receipt.goodreceipt.materialCode);
          new_material.receivedQuantity=receipt.goodreceipt.receivedQuantity
          new_material.availableQuantity=receipt.goodreceipt.receivedQuantity
        
          new_material.purchaseOrder=[update_po]
        console.log(new_material)
         await materialRegistry.add(new_material)
      }
    }
    const newgood_reciept = factory.newResource('com.cts.ipm.p2pNetwork', 'GoodReceipt', receipt.receiptId);
    newgood_reciept=receipt
    registry.add(newgood_reciept)
     }
  else{
      throw console.error("no batch with given id");
      
  }
    
    }
    else{
      throw console.error("no product with given id");
      
  }
  
  }
/**
 * Search the order by poNumber
 * @param {com.cts.ipm.p2pNetwork.ShipmentNotification} shipment - 
 * @transaction
 */
async function ShipmentNotification(shipment) {  // eslint-disable-line no-unused-vars
    const registry = await getAssetRegistry('com.cts.ipm.p2pNetwork.DeliveryNote');
  	const orderRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.PurchaseOrder');
    const batchregistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.newBatch');
  	const factory = getFactory();
  	const results = await query('selectProductBypoNumber', {poNumber : shipment.deliverynote.poNumber});
  	if(results.length>0) {
      const update_order = await orderRegistry.get(shipment.deliverynote.poNumber);
      if(parseInt(shipment.batch.shippedQuantity)<=parseInt(update_order.purchaseorder.requiredQuantity)){
    const deliveryNote = factory.newResource('com.cts.ipm.p2pNetwork', 'DeliveryNote', shipment.batchId);
    deliveryNote.note = shipment.deliverynote;
    deliveryNote.batchId=shipment.batchId
    await registry.add(deliveryNote)  
      
    update_order.purchaseorder.shippedQuantity=(parseInt(update_order.purchaseorder.shippedQuantity)+parseInt(shipment.batch.shippedQuantity)).toString();
    update_order.purchaseorder.requiredQuantity=(update_order.purchaseorder.requiredQuantity-shipment.batch.shippedQuantity).toString(); 
    const batch = factory.newResource('com.cts.ipm.p2pNetwork', 'newBatch', shipment.batchId);
    batch.batch=shipment.batch
    batch.batch.recievedQuantity="0"
    batch.batch.availableQuantity="0"   
    batch.batch.batchStatus="Shipped"
    update_order.purchaseorder.batch.push(batch)
    await orderRegistry.update(update_order)  
        await batchregistry.add(batch)
      }
      else
      throw new Error('Shipped Quantity greater than required quantity');
    }
    else
      throw new Error('Order  not available for the given poNumber');   
  }



    
/**
   * Place an order for the material
   * @param {com.cts.ipm.p2pNetwork.PlaceOrder} placeOrder - the PlaceOrder transaction
   * @transaction
   */
async function PlaceOrder(orderRequest) {
    const registry = await getAssetRegistry('com.cts.ipm.p2pNetwork.PurchaseOrder');
    const factory = getFactory();
    var namespace = 'com.cts.ipm.p2pNetwork';
    const order = factory.newResource('com.cts.ipm.p2pNetwork', 'PurchaseOrder', orderRequest.poNumber);
    order.purchaseorder = orderRequest.purchaseorder;
    order.purchaseorder.requiredQuantity = orderRequest.purchaseorder.orderQuantity
    order.purchaseorder.shippedQuantity = "0";
    order.purchaseorder.receivedQuantity = "0";
  	order.purchaseorder.availableQuantity = "0";
  
    orderRequest.purchaseorder.orderStatus = "open";
    await registry.add(order)

  
}


/**
   * Place an order for the material
   * @param {com.cts.ipm.p2pNetwork.InvoiceStatus} status - the PlaceOrder transaction
   * @transaction
   */
async function InvoiceStatus(status) {
 const invoiceRegisry = await getAssetRegistry('com.cts.ipm.p2pNetwork.SelfInvoice');  
    const factory = getFactory();
    var namespace = 'com.cts.ipm.p2pNetwork';
  const invoice = await query('selectProductByinvDocNum', {invDocNum : status.invDocNum});
  console.log(invoice)
  if(invoice.length >0){
    invoice[0].invoiceStatus = "Status Pending"
    console.log(invoice)
    await invoiceRegisry.update(invoice)
  }
  
}



/**new_material
 * Search the order by poNumber
 * @param {com.cts.ipm.p2pNetwork.generateInvoice} generate - 
 * @transaction
 */
 async function generateInvoice(generateinvoice) {  // eslint-disable-line no-unused-vars
    const namespace = "com.cts.ipm.p2pNetwork";
      const factory = getFactory();
      const materialRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.Material');
   const invoiceRegisry = await getAssetRegistry('com.cts.ipm.p2pNetwork.SelfInvoice');  
    const orderRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.PurchaseOrder');
   
      const materials = await query('selectMaterial');
   
      console.log(materials)
   
   if(materials.length>0) {
    
   
    for(let i=0;i<materials.length;i++)
    {
      
      for(let j=0;j<materials[i].batch.length;j++){
        const order = await query('selectProductBypoNumber', {poNumber : materials[i].batch[j].poNumber});
         //const material = await query('selectProductBypoNumber', {poNumber : materials[i].batch[j].poNumber});
        const new_material = await materialRegistry.get(materials[i].batch[j].poNumber);
        console.log("materials[i].batch[j].poNumber")
        console.log(materials[i].batch[j].poNumber)
        //console.log("newmaterial")
       // console.log(newmaterial[i].batch[j])
      if(materials[i].batch[j].quantity > 0 )
      {      
        let invDocNum = 0;
     invDocNum = generateinvoice.invDocNum.toString()+1;
     generateinvoice.invDocNum = invDocNum
    var datetime = new Date();
    console.log(datetime);
    var date1 = new Date(datetime);
    console.log(materials[i].batch[j].receiptDate);
	var date2 = new Date(materials[i].batch[j].receiptDate);
	var timeDiff = Math.abs(date2.getTime() - date1.getTime());
	var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
       // const Material = factory.newResource('com.cts.ipm.p2pNetwork', 'Material', results[i].batch[j].materialCode);
	console.log(diffDays);
        if(diffDays > 90){  
                   
   const invoice = factory.newResource('com.cts.ipm.p2pNetwork', 'SelfInvoice',generateinvoice.invDocNum);
   invoice.selfinvoice = materials[i].batch[j];
   invoice.amount = order[0].purchaseorder.price;
          console.log("invoice.selfinvoice")
          console.log(invoice.selfinvoice)
   invoice.selfinvoice.invoiceStatus = "Invoice Generated"
  invoice.invoiceStatus = "Invoice Generated"
           console.log(invoice.selfinvoice)
          
  await invoiceRegisry.add(invoice)      
          //invDocNum =  invDocNum + 1;
          
         materials[i].batch[j].invoiceStatus = "Invoice Generated"
          console.log(materials)
         await materialRegistry.update();  
          
        }
      }
          }
    }
}   
    }







  
  

/**
   * Place an order for the material
   * @param {com.cts.ipm.p2pNetwork.dateDifference} placeOrder - the PlaceOrder transaction
   * @transaction
   */
async function dateDifference(orderRequest) {
    const registry = await getAssetRegistry('com.cts.ipm.p2pNetwork.Material');
    const factory = getFactory();
    var namespace = 'com.cts.ipm.p2pNetwork';
    const material_results = await query('selectMaterial');
  console.log(material_results)
  if(material_results.length>0){
    for(let i=0;i<material_results.length;i++){
      for(let j=0;j<material_results[i].batch.length;j++){
        if(material_results[i].batch[j].quantity>0){
          console.log(material_results[i].batch[j])
          console.log("This batch is consumed");
           var datetime = new Date();
    console.log(datetime);
    var date1 = new Date(datetime);
    console.log(material_results[i].batch[j].receiptDate);
	var date2 = new Date(material_results[i].batch[j].receiptDate);
	var timeDiff = Math.abs(date2.getTime() - date1.getTime());
	var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
	console.log(diffDays);
        if(diffDays > 90){
          console.log("inside date difference")
              const DateDifferenceEvent = factory.newEvent('com.cts.ipm.p2pNetwork', 'DateDifferenceEvent');
    console.log("event emitted" +material_results[i]);
          console.log(material_results[i].batch[j])
          console.log("DateDifferenceEvent")
          console.log(DateDifferenceEvent)
    DateDifferenceEvent.poNumber = material_results[i].batch[j].poNumber
          DateDifferenceEvent.batchId = material_results[i].batch[j].batchId
          console.log(DateDifferenceEvent)
          DateDifferenceEvent.quantity = material_results[i].batch[j].quantity
    DateDifferenceEvent.materialCode = material_results[i].batch[j].materialCode;
    emit(DateDifferenceEvent);
        }
          
        }
      }
    }
  }
}


/**
   * Place an order for the material
   * @param {com.cts.ipm.p2pNetwork.displayInvoice} displayinvoice - the PlaceOrder transaction
   * @transaction
   */

 async function displayInvoice(search) {
    const factory = getFactory();
    const results = await query('selectInvoice');
  //console.log(results)
  
  if(results.length>0) {
   // console.log(results)
    for(let i=0;i<results.length;i++){
    const SearchInvoiceEvent = factory.newEvent('com.cts.ipm.p2pNetwork', 'SearchInvoiceEvent');
    //console.log("event emitted" +results[i]);
      SearchInvoiceEvent.invDocNum = results[i].invDocNum;
    SearchInvoiceEvent.selfinvoice = results[i].selfinvoice;
      SearchInvoiceEvent.amount = results[i].amount;
      SearchInvoiceEvent.invoiceStatus = results[i].invoiceStatus;
      
   // SearchOrderEvent.purchaseorder = results[i].purchaseorder;
    emit(SearchInvoiceEvent);
	//new_order.purchaseorder = results[0].purchaseorder;
   // await productRegistry.update(new_order); 
  } 
   const material_results = await query('selectMaterial');
  console.log(material_results)
   
 /* for(let i=0;i<material_results.length;i++){
     for(let j=0;j<material_results[i].batch.length;j++){
       console.log("inside first for loop")
       if(material_results[i].batch[j].qantity>0){
     var datetime = new Date();
    console.log(datetime);
    var date1 = new Date(datetime);
    console.log(material_results[i].batch[j].receiptDate);
	var date2 = new Date(material_results[i].batch[j].receiptDate);
	var timeDiff = Math.abs(date2.getTime() - date1.getTime());
	var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
	console.log(diffDays);
        if(diffDays > 90){      
    const SearchGreaterInvoiceEvent = factory.newEvent('com.cts.ipm.p2pNetwork', 'SearchGreaterInvoiceEvent');
     SearchGreaterInvoiceEvent.invDocNum = results[i].invDocNum;
    SearchGreaterInvoiceEvent.selfinvoice = results[i].selfinvoice;
      SearchGreaterInvoiceEvent.amount = results[i].amount;
      SearchGreaterInvoiceEvent.invoiceStatus = results[i].invoiceStatus;
    emit(SearchGreaterInvoiceEvent);
        }
       }
       
  }
   
  }*/ } else{
    throw new Error('Supplier not available for given id'); 
   }

  }


/**
   * Place an order for the material
   * @param {com.cts.ipm.p2pNetwork.displayNewInvoice} displayinvoice - the PlaceOrder transaction
   * @transaction
   */

 async function displayNewInvoice(search) {
    const factory = getFactory();
    const results = await query('selectInvoice');
  //console.log(results)
   const material_results = await query('selectMaterial');
  console.log(material_results)
   if(material_results.length>0) {
  for(let i=0;i<material_results.length;i++){
     for(let j=0;j<material_results[i].batch.length;j++){
       console.log("inside first for loop")
       if(material_results[i].batch[j].qantity>0){
             var datetime = new Date();
    console.log(datetime);
    var date1 = new Date(datetime);
    console.log(material_results[i].batch[j].receiptDate);
	var date2 = new Date(material_results[i].batch[j].receiptDate);
	var timeDiff = Math.abs(date2.getTime() - date1.getTime());
	var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
	console.log(diffDays);
        if(diffDays > 90){      
    const SearchGreaterInvoiceEvent = factory.newEvent('com.cts.ipm.p2pNetwork', 'SearchGreaterInvoiceEvent');
     SearchGreaterInvoiceEvent.invDocNum = results[i].invDocNum;
    SearchGreaterInvoiceEvent.selfinvoice = results[i].selfinvoice;
      SearchGreaterInvoiceEvent.amount = results[i].amount;
      SearchGreaterInvoiceEvent.invoiceStatus = results[i].invoiceStatus;
    emit(SearchGreaterInvoiceEvent);
        }
       }
       
     }
  }
   }
   else
    throw new Error('Supplier not available for given id');

  }

/**
   * Place an order for the material
   * @param {com.cts.ipm.p2pNetwork.Payment} payment - the PlaceOrder transaction
   * @transaction
   */
async function Payment(create) {
    const registry = await getAssetRegistry('com.cts.ipm.p2pNetwork.SelfInvoice');
    const factory = getFactory();
    var namespace = 'com.cts.ipm.p2pNetwork';
  const new_order = await registry.get(create.invDocNum);
  const results = await query('selectProductByinvDocNum', {invDocNum : create.invDocNum});
  console.log(results[0])
  if(results.length>0){
    
   new_order.invoiceStatus = "Payment Sucessfull"
    await registry.update(new_order)

                         }
  else
    throw new Error ("Payment cannot be done")
}

/**
 * Search the order by poNumbera
 * @param {com.cts.ipm.p2pNetwork.display} display - 
 * @transaction
 */
async function display(display) {  // eslint-disable-line no-unused-vars
 // const MaterialRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.Material');
   const factory = getFactory();
    
 const results = await query('selectMaterial');
  console.log(results)
  if(results.length>0) {
    for(let i=0;i<results.length;i++)
    {
      for(let j=0;j<results[i].batch.length;j++){
      if(results[i].batch[j].quantity > 0 )
      {          
    var datetime = new Date();
    console.log(datetime);
    var date1 = new Date(datetime);
    console.log(results[i].batch[j].receiptDate);
	var date2 = new Date(results[i].batch[j].receiptDate);
	var timeDiff = Math.abs(date2.getTime() - date1.getTime());
	var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
       // const Material = factory.newResource('com.cts.ipm.p2pNetwork', 'Material', results[i].batch[j].materialCode);
	console.log(diffDays);
        if(diffDays > 90){
        
         // if(results[i].batch[j].invoiceStatus == "Invoice Generated")
        //  {          
     const displayEvent = factory.newEvent('com.cts.ipm.p2pNetwork', 'displayEvent');
    console.log("event emitted" +results[i]);
    displayEvent.batch = results[i].batch;
    emit(displayEvent);
         //  }
        }
      }
          }
    }
}
  else
    throw new Error('Order  not available for the given poNumber');   
}




/**
   * Place an order for the material
   * @param {com.cts.ipm.p2pNetwork.searchInvoice} displayinvoice - the PlaceOrder transaction
   * @transaction
   */
async function searchInvoice(search) {
    const results = await query('selectProductByinvoiceId', {invDocNum : search.invDocNum});
   const factory = getFactory();
      const productRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.SelfInvoice');
  console.log(results)
  if(results.length>0) {
    for(let i=0;i<results.length;i++){
   

   // const new_order = await productRegistry.get(search.supplier);
   // console.log(new_order)
    
    const SearchInvoiceEvent = factory.newEvent('com.cts.ipm.p2pNetwork', 'SearchInvoiceEvent');
    console.log("event emitted" +results[i]);
    SearchInvoiceEvent.invDocNum = results[i].invDocNum;
    SearchInvoiceEvent.selfinvoice = results[i].selfinvoice;
      SearchInvoiceEvent.amount = results[i].amount;
      SearchInvoiceEvent.invoiceStatus = results[i].invoiceStatus;
      
    emit(SearchInvoiceEvent);
	//new_order.purchaseorder = results[0].purchaseorder;
   // await productRegistry.update(new_order); 
  }
  }
  else
    throw new Error('Invoice not available for given id');   
  }








  
   /*const receiptRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.GoodReceipt');
   const new_material = await receiptRegistry.get(orderRequest.poNumber);
  console.log(new_material)*/
    
  



/**
 * Search the order by poNumbera
 * @param {com.cts.ipm.p2pNetwork.searchOrder} search - 
 * @transaction
 */
async function searchOrder(search) {  // eslint-disable-line no-unused-vars

  const results = await query('selectProductBypoNumber', {poNumber : search.poNumber});
  if(results.length>0) {
    const factory = getFactory();
    const productRegistry = await getAssetRegistry('com.cts.ipm.p2pNetwork.PurchaseOrder'); 
    const new_order = await productRegistry.get(search.poNumber);
    
    const SearchOrderEvent = factory.newEvent('com.cts.ipm.p2pNetwork', 'SearchOrderEvent');
    console.log("event emitted" +results[0]);
    SearchOrderEvent.poNumber = results[0].poNumber;
    SearchOrderEvent.purchaseorder = results[0].purchaseorder;
    emit(SearchOrderEvent);
	new_order.purchaseorder = results[0].purchaseorder;
    await productRegistry.update(new_order); 
  }
  else
    throw new Error('Order  not available for the given poNumber');   
}



